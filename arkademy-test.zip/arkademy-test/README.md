# test-dickyindra
Syarat untuk mengikuti tes Bootcamp Arkhademy

# configurasi database
Untuk soal nomor 6 dan 7 membutuhkan database, silahkan import database 'blogku.sql' yang telah tersedia ke database mysql.
